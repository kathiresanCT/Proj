package com.example.demo.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
public class GuestUser {

	public Integer id;
	@Value("${s.name:hii}")
	public String name;
	
	@Value("${s.ext:external}")
	public String external;
	public GuestUser(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public Integer getId() {
		return id;
	}
	public GuestUser() {
		// TODO Auto-generated constructor stub
	}
}
