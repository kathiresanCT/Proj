package com.example.demo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
@ComponentScan(basePackages="com.example.demo.model")
@PropertySource("C:\\Users\\kathiresann\\Desktop\\my.properties")
public class AppConfig {
}
